package ru.sourcenav.app

import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import ru.sourcenav.app.location.LocationTracker
import ru.sourcenav.app.routing.RoutingApi
import ru.sourcenav.app.ui.NavigatorScreen
import ru.sourcenav.app.voice.NavigatorSpeaker
import ru.sourcenav.app.voice.SpeechListener
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {

    private lateinit var speech: SpeechListener
    private lateinit var speaker: NavigatorSpeaker
    private lateinit var location: LocationTracker
    private lateinit var controller: NavigationController

    /** Последняя известная позиция — нужна как начало маршрута. */
    private var currentPoint: RoutingApi.Point? = null

    private var pendingMicAction: () -> Unit = {}

    private val requestMic =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
            if (granted) pendingMicAction() else controller.onSpeechError(
                getString(R.string.state_no_permission)
            )
        }

    private val requestLocation =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
            if (granted) startLocation() else controller.onSpeechError(
                getString(R.string.state_no_location_permission)
            )
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        speaker = NavigatorSpeaker(this)
        controller = NavigationController(
            scope = lifecycleScope,
            speak = { text -> speaker.speak(text) },
            onStateChanged = { /* перерисовку даёт Compose — состояние observable */ },
        )

        speech = SpeechListener(
            context = this,
            onResult = { address -> controller.onAddressRecognized(address, currentPoint) },
            onError = { message -> controller.onSpeechError(message) },
        )

        location = LocationTracker(this) { point, accuracy ->
            currentPoint = point
            controller.onPosition(point, accuracy)
        }

        setContent {
            NavigatorScreen(
                state = controller.state,
                onListenRequested = { startListeningWithPermission() },
                onSpeakRequested = { text -> speaker.speak(text) },
            )
        }

        ensureLocationPermission()
    }

    private fun ensureLocationPermission() {
        val granted = ContextCompat.checkSelfPermission(
            this,
            Manifest.permission.ACCESS_FINE_LOCATION,
        ) == PackageManager.PERMISSION_GRANTED

        if (granted) startLocation() else requestLocation.launch(Manifest.permission.ACCESS_FINE_LOCATION)
    }

    private fun startLocation() {
        location.start()
    }

    private fun startListeningWithPermission() {
        val granted = ContextCompat.checkSelfPermission(
            this,
            Manifest.permission.RECORD_AUDIO,
        ) == PackageManager.PERMISSION_GRANTED

        if (granted) {
            speech.start()
        } else {
            // Экран уже объяснил, зачем микрофон: сначала произносим
            // объяснение, только потом показываем системный запрос.
            speaker.speak(getString(R.string.state_no_permission))
            pendingMicAction = { speech.start() }
            requestMic.launch(Manifest.permission.RECORD_AUDIO)
        }
    }

    override fun onStop() {
        super.onStop()
        // Экран погашен — GPS выключаем. Постоянное ведение в фоне
        // появится отдельным сервисом, это следующая веха: сейчас
        // батарея важнее.
        location.stop()
    }

    override fun onStart() {
        super.onStart()
        if (location.hasPermission()) location.start()
    }

    override fun onDestroy() {
        speech.release()
        speaker.release()
        location.stop()
        super.onDestroy()
    }
}
