package ru.sourcenav.app

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import ru.sourcenav.app.routing.NavigationEngine
import ru.sourcenav.app.routing.RoutingApi

/**
 * Связующее звено: адрес, маршрут, положение, голос.
 *
 * Всё состояние навигации живёт здесь, а экран только показывает то,
 * что уже решено. Так проще рассуждать о поведении: единственное место,
 * которое знает, на каком мы шаге маршрута и что уже было сказано.
 */
class NavigationController(
    private val scope: CoroutineScope,
    private val speak: (String) -> Unit,
    private val onStateChanged: () -> Unit,
) {
    var state: NavState by mutableStateOf(NavState.Idle)
        private set

    private var engine: NavigationEngine? = null

    /** Адрес распознан голосом — строим маршрут. */
    fun onAddressRecognized(address: String, from: RoutingApi.Point?) {
        scope.launch {
            state = NavState.Loading(address)
            onStateChanged()

            if (from == null) {
                // Координат ещё нет: без них маршрут не построить, и
                // честнее сказать об этом, чем молча ждать.
                finish(NavState.Error("Жду сигнал GPS, попробуйте ещё раз через минуту"))
                return@launch
            }

            val target = withContext(Dispatchers.IO) { RoutingApi.geocode(address) }
            if (target == null) {
                finish(NavState.Error("Не нашёл такой адрес. Назовите иначе, например с улицей и номером дома"))
                return@launch
            }

            val route = withContext(Dispatchers.IO) { RoutingApi.route(from, target) }
            if (route == null || route.maneuvers.isEmpty()) {
                finish(NavState.Error("Не получилось построить пеший маршрут до этого адреса"))
                return@launch
            }

            engine = NavigationEngine(route)
            state = NavState.Guiding(
                target = address,
                nextInstruction = route.maneuvers.first().instruction,
                remainingMeters = route.totalMeters,
            )
            onStateChanged()
            speak("Маршрут построен. ${route.maneuvers.first().instruction}")
        }
    }

    /** Пришла новая координата от GPS. */
    fun onPosition(point: RoutingApi.Point, accuracyMeters: Double) {
        val active = engine ?: return
        val cue = active.onPosition(point, NavigationEngine.Accuracy(accuracyMeters)) ?: return

        if (active.isFinished) {
            finish(NavState.Arrived)
            speak(active.onArrived())
            return
        }

        state = NavState.Guiding(
            target = (state as? NavState.Guiding)?.target.orEmpty(),
            nextInstruction = cue,
            remainingMeters = active.remainingToManeuver(),
        )
        onStateChanged()
        speak(cue)
    }

    fun onSpeechError(message: String) = finish(NavState.Error(message))

    private fun finish(next: NavState) {
        state = next
        onStateChanged()
    }
}

sealed interface NavState {
    data object Idle : NavState
    data object Listening : NavState
    data class Loading(val address: String) : NavState
    data class Guiding(
        val target: String,
        val nextInstruction: String,
        val remainingMeters: Double,
    ) : NavState
    data object Arrived : NavState
    data class Error(val message: String) : NavState
}
