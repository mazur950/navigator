package ru.sourcenav.app.location

import android.Manifest
import android.annotation.SuppressLint
import android.content.Context
import android.content.pm.PackageManager
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.os.Bundle
import androidx.core.content.ContextCompat
import ru.sourcenav.app.routing.RoutingApi

/**
 * Положение пользователя на местности.
 *
 * Берём только GPS, без сети: для пешеходной навигации важнее точность
 * на открытом воздухе, а сетевые координаты в городе часто указывают
 * на соседний квартал. Заодно экономим батарею — обновления приходят
 * раз в секунду, чего пешеходу достаточно.
 *
 * Вместе с координатой всегда отдаём погрешность. Навигатор обязан
 * знать, насколько можно себе доверять: подсказка на повороте при
 * погрешности в 40 метров уводит не туда.
 */
class LocationTracker(
    private val context: Context,
    private val onPosition: (RoutingApi.Point, Double) -> Unit,
) {
    private val manager =
        context.getSystemService(Context.LOCATION_SERVICE) as LocationManager

    private var listening = false

    fun hasPermission(): Boolean =
        ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_FINE_LOCATION) ==
            PackageManager.PERMISSION_GRANTED

    @SuppressLint("MissingPermission")
    fun start() {
        if (listening || !hasPermission()) return
        if (!manager.isProviderEnabled(LocationManager.GPS_PROVIDER)) return

        manager.requestLocationUpdates(
            LocationManager.GPS_PROVIDER,
            MIN_INTERVAL_MS,
            MIN_DISTANCE_M,
            listener,
        )
        listening = true
    }

    fun stop() {
        if (!listening) return
        manager.removeUpdates(listener)
        listening = false
    }

    private val listener = object : LocationListener {
        override fun onLocationChanged(location: Location) {
            onPosition(
                RoutingApi.Point(location.latitude, location.longitude),
                location.accuracy.toDouble(),
            )
        }

        override fun onProviderDisabled(provider: String) = Unit
        override fun onProviderEnabled(provider: String) = Unit

        @Deprecated("Обязательная сигнатура старого интерфейса")
        override fun onStatusChanged(provider: String?, status: Int, extras: Bundle?) = Unit
    }

    private companion object {
        const val MIN_INTERVAL_MS = 1_000L
        const val MIN_DISTANCE_M = 1.0f
    }
}
