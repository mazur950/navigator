package ru.sourcenav.app.routing

import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.sin
import kotlin.math.sqrt

/**
 * Ведение по маршруту: где мы сейчас относительно манёвра и что сказать.
 *
 * Задача незрячего пешехода отличается от водительской. Водителю можно
 * сказать «через 200 метров поверните направо» — он едет по дороге и
 * увидит поворот. Пешеход идёт медленно, у поворотов во дворах нет
 * табличек, а GPS в плотной застройке врёт на 10–20 метров. Поэтому
 * подсказки выдаются ступенями: сначала на подходе, потом перед самим
 * манёвром, и последняя — уже на месте.
 *
 * Зона, в которой срабатывает подсказка, растёт вместе с погрешностью
 * GPS: если сигнал плохой, раньше предупредим, но не будем дёргать
 * пользователя ложными поворотами.
 */
class NavigationEngine(private val route: RoutingApi.Route) {

    /** Насколько точно мы знаем своё положение, в метрах. */
    data class Accuracy(val meters: Double) {
        // При погрешности выше 30 метров подсказки на поворотах
        // становятся вредными: они указывают не тот перекрёсток.
        val isUsable: Boolean get() = meters <= 30.0
    }

    enum class Stage { Approach, Now, Done }

    private var currentIndex = 0
    private var announcedApproach = false

    val isFinished: Boolean get() = currentIndex >= route.maneuvers.size

    /**
     * Точка, к которой идём сейчас. Если манёвры кончились — конечная
     * точка маршрута.
     */
    fun currentTarget(): RoutingApi.Point? =
        route.points.lastOrNull()

    /**
     * Расстояние до конца текущего манёвра. Пока маршрут не разложен
     * по шагам с геометрией, считаем по длине манёвров, оставшихся
     * впереди — этого достаточно, чтобы вести по прямой.
     */
    fun remainingToManeuver(): Double =
        route.maneuvers.drop(currentIndex).firstOrNull()?.distanceMeters ?: 0.0

    /**
     * Что сказать на текущей позиции, или null — если говорить нечего
     * и лучше промолчать, чем шуметь в ухо.
     */
    fun onPosition(position: RoutingApi.Point, accuracy: Accuracy): String? {
        if (isFinished) return null

        val maneuver = route.maneuvers.getOrNull(currentIndex) ?: return null

        if (!accuracy.isUsable) {
            // Плохой сигнал: молчим о поворотах, но если пользователь
            // совсем потерялся — это лучше сказать.
            return null
        }

        val ahead = remainingToManeuver()

        return when {
            ahead <= APPROACH_METERS && !announcedApproach -> {
                announcedApproach = true
                "${maneuver.instruction}. Через ${ahead.toInt()} метров"
            }
            ahead <= NOW_METERS -> {
                currentIndex++
                announcedApproach = false
                maneuver.instruction
            }
            else -> null
        }
    }

    /** Пройден ли маршрут целиком. */
    fun onArrived(): String = "Вы на месте"

    companion object {
        /** Зона предупреждения на подходе. */
        const val APPROACH_METERS = 30.0

        /** Зона, в которой манёвр объявляется как «сейчас». */
        const val NOW_METERS = 8.0

        /** Расстояние между двумя координатами по поверхности земли. */
        fun distanceMeters(a: RoutingApi.Point, b: RoutingApi.Point): Double {
            val r = 6_371_000.0
            val dLat = Math.toRadians(b.lat - a.lat)
            val dLon = Math.toRadians(b.lon - a.lon)
            val lat1 = Math.toRadians(a.lat)
            val lat2 = Math.toRadians(b.lat)
            val h = sin(dLat / 2) * sin(dLat / 2) +
                cos(lat1) * cos(lat2) * sin(dLon / 2) * sin(dLon / 2)
            return 2 * r * atan2(sqrt(h), sqrt(1 - h))
        }
    }
}
