package ru.sourcenav.app.routing

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

/**
 * Геокодирование и построение пешего маршрута.
 *
 * За основу взят публичный серверный API OpenStreetMap (Nominatim для
 * адресов, OSRM для маршрутов). Причины две: он бесплатный и у него
 * нет требований к ключам — а значит, приложение можно собрать и
 * проверить, ничего не регистрируя. Для личного использования этого
 * хватает с запасом.
 *
 * Когда проект выйдет за пределы личного, оба вызова стоит увести за
 * свой прокси: у Nominatim жёсткий лимит на запросы с одного адреса, и
 * публичный сервер не рассчитан на поток пользователей.
 */
object RoutingApi {

    private const val NOMINATIM = "https://nominatim.openstreetmap.org/search"
    private const val OSRM = "https://router.project-osrm.org/route/v1/foot"

    // У Nominatim обязателен осмысленный User-Agent, иначе запросы режутся.
    private const val UA = "SourceNavigator/0.1 (personal accessibility project)"

    data class Point(val lat: Double, val lon: Double)
    data class Maneuver(val instruction: String, val distanceMeters: Double)
    data class Route(val points: List<Point>, val maneuvers: List<Maneuver>) {
        val totalMeters: Double get() = maneuvers.sumOf { it.distanceMeters }
    }

    /** Адрес, произнесённый голосом, превращаем в координату. */
    suspend fun geocode(address: String): Point? = withContext(Dispatchers.IO) {
        val url = URL(
            "$NOMINATIM?format=json&limit=1&q=" +
                URLEncoder.encode(address, "UTF-8")
        )
        val body = httpGet(url) ?: return@withContext null
        val arr = JSONObject(body).optJSONArray("place") ?: run {
            // Nominatim отдаёт массив верхнего уровня, а не объект.
            val root = org.json.JSONArray(body)
            if (root.length() == 0) return@withContext null
            return@withContext root.getJSONObject(0).let {
                Point(it.getString("lat").toDouble(), it.getString("lon").toDouble())
            }
        }
        if (arr.length() == 0) return@withContext null
        Point(
            arr.getJSONObject(0).getString("lat").toDouble(),
            arr.getJSONObject(0).getString("lon").toDouble(),
        )
    }

    /** Пеший маршрут между двумя точками. */
    suspend fun route(from: Point, to: Point): Route? = withContext(Dispatchers.IO) {
        val coords = "${from.lon},${from.lat};${to.lon},${to.lat}"
        val url = URL("$OSRM/$coords?overview=full&geometries=geojson&steps=true")
        val body = httpGet(url) ?: return@withContext null

        val root = JSONObject(body)
        val route = root.optJSONArray("routes")?.optJSONObject(0) ?: return@withContext null

        val points = route.getJSONObject("geometry")
            .getJSONArray("coordinates")
            .let { arr ->
                (0 until arr.length()).map { i ->
                    val pair = arr.getJSONArray(i)
                    // GeoJSON хранит координаты в порядке долгота-широта.
                    Point(pair.getDouble(1), pair.getDouble(0))
                }
            }

        val maneuvers = route.getJSONArray("legs")
            .getJSONObject(0)
            .getJSONArray("steps")
            .let { steps ->
                (0 until steps.length()).mapNotNull { i ->
                    val step = steps.getJSONObject(i)
                    val maneuver = step.optJSONObject("maneuver") ?: return@mapNotNull null
                    val type = maneuver.optString("type")
                    val modifier = maneuver.optString("modifier")
                    Maneuver(
                        instruction = humanize(type, modifier, step),
                        distanceMeters = step.optDouble("distance", 0.0),
                    )
                }
            }

        Route(points = points, maneuvers = maneuvers)
    }

    /**
     * Перевод машинного типа манёвра в фразу, которую не стыдно
     * произнести вслух. OSRM отдаёт `turn` + `right`, а незрячему
     * человеку нужно «поверните направо».
     */
    private fun humanize(type: String, modifier: String, step: JSONObject): String {
        val road = step.optString("name").takeIf { it.isNotBlank() }
        val onRoad = if (road != null) " на $road" else ""

        return when (type) {
            "depart" -> "Начинайте движение по маршруту"
            "arrive" -> "Вы на месте"
            "turn" -> when (modifier) {
                "left" -> "Поверните налево$onRoad"
                "right" -> "Поверните направо$onRoad"
                "slight left" -> "Плавно налево$onRoad"
                "slight right" -> "Плавно направо$onRoad"
                "sharp left" -> "Резко налево$onRoad"
                "sharp right" -> "Резко направо$onRoad"
                "uturn" -> "Развернитесь$onRoad"
                else -> "Продолжайте движение$onRoad"
            }
            "new name" -> "Продолжайте движение$onRoad"
            "continue" -> "Продолжайте движение$onRoad"
            "roundabout", "rotary" -> "Войдите на круг$onRoad"
            "merge" -> "Присоединитесь к движению$onRoad"
            "fork" -> if (modifier.contains("left")) "Держитесь левее$onRoad"
                      else "Держитесь правее$onRoad"
            "end of road" -> if (modifier.contains("left")) "В конце дороги поверните налево$onRoad"
                             else "В конце дороги поверните направо$onRoad"
            "crosswalk" -> "Перейдите дорогу"
            else -> "Продолжайте движение$onRoad"
        }
    }

    private fun httpGet(url: URL): String? = try {
        (url.openConnection() as HttpURLConnection).run {
            requestMethod = "GET"
            setRequestProperty("User-Agent", UA)
            connectTimeout = 10_000
            readTimeout = 10_000
            try {
                if (responseCode == 200) inputStream.bufferedReader().readText() else null
            } finally {
                disconnect()
            }
        }
    } catch (e: Exception) {
        null
    }
}
