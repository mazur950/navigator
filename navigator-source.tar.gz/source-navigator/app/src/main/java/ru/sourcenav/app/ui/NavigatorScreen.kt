package ru.sourcenav.app.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.liveRegion
import androidx.compose.ui.semantics.LiveRegionMode
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.unit.dp
import ru.sourcenav.app.NavState
import ru.sourcenav.app.R

/**
 * Единственный экран навигатора.
 *
 * Правила, по которым он собран, продиктованы тем, кто им пользуется.
 *
 * Каждый элемент несёт contentDescription — без него TalkBack произносит
 * «кнопка», и экран превращается в набор безымянных прямоугольников.
 *
 * Строка состояния объявлена live region: TalkBack сам зачитывает её
 * при изменении, без касания экрана. Это принципиально — пользователь
 * идёт и не может тыкать в телефон на каждом повороте.
 *
 * Порядок обхода задан расположением сверху вниз, а не визуальной
 * логикой: незрячий человек листает элементы свайпами в одном
 * направлении, и порядок для него и есть структура экрана.
 *
 * Экран не хранит состояния навигации — оно в NavigationController.
 * Здесь только показ.
 */
@Composable
fun NavigatorScreen(
    state: NavState,
    onListenRequested: () -> Unit,
    onSpeakRequested: (String) -> Unit,
) {
    val res = LocalContext.current.resources

    val statusText = when (state) {
        NavState.Idle -> res.getString(R.string.state_idle)
        NavState.Listening -> res.getString(R.string.state_listening)
        is NavState.Loading -> res.getString(R.string.state_loading, state.address)
        is NavState.Guiding -> res.getString(
            R.string.state_guiding,
            state.nextInstruction,
            state.remainingMeters.toInt(),
        )
        NavState.Arrived -> res.getString(R.string.state_arrived)
        is NavState.Error -> state.message
    }

    Surface(
        modifier = Modifier.fillMaxSize(),
        color = MaterialTheme.colorScheme.background,
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(24.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp),
        ) {
            Text(
                text = statusText,
                style = MaterialTheme.typography.headlineSmall,
                modifier = Modifier
                    .fillMaxWidth()
                    .semantics {
                        contentDescription = statusText
                        liveRegion = LiveRegionMode.Polite
                    },
            )

            Button(
                onClick = {
                    onSpeakRequested(res.getString(R.string.state_listening))
                    onListenRequested()
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .semantics {
                        contentDescription = res.getString(R.string.action_speak_destination_hint)
                    },
            ) {
                Text(res.getString(R.string.action_speak_destination))
            }

            // Повторить последнюю подсказку. Нужно чаще, чем кажется:
            // на улице шумно, фраза пролетает мимо, а трогать экран
            // ради переспроса незрячему человеку тяжело.
            Button(
                onClick = { onSpeakRequested(statusText) },
                modifier = Modifier
                    .fillMaxWidth()
                    .semantics { contentDescription = res.getString(R.string.action_repeat) },
            ) {
                Text(res.getString(R.string.action_repeat))
            }
        }
    }
}
