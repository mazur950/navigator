package ru.sourcenav.app.voice

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFocusRequest
import android.media.AudioManager
import android.os.Build
import android.speech.tts.TextToSpeech
import java.util.Locale
import java.util.UUID

/**
 * Голос навигатора.
 *
 * Ключевая деталь всей затеи: подсказки идут по каналу
 * AUDIOFOCUS_GAIN_TRANSIENT_MAY_DUCK, из-за чего TalkBack на время
 * фразы приглушается, а не говорит одновременно с навигатором.
 * Если этого не сделать, два синтезатора перекрывают друг друга и
 * разобрать подсказку невозможно.
 *
 * Поэтому же используется USAGE_ASSISTANCE_NAVIGATION_GUIDANCE —
 * это отдельный от медиа канал, который система не путает с музыкой.
 */
class NavigatorSpeaker(context: Context) {

    private val audioManager =
        context.getSystemService(Context.AUDIO_SERVICE) as AudioManager

    private var tts: TextToSpeech? = null
    private var ready = false
    private var pending: String? = null
    private var focusRequest: AudioFocusRequest? = null

    init {
        tts = TextToSpeech(context.applicationContext) { status ->
            if (status == TextToSpeech.SUCCESS) {
                tts?.language = Locale("ru")
                ready = true
                pending?.let { speak(it) }
                pending = null
            } else {
                ready = false
            }
        }
    }

    /** Произнести подсказку. Можно звать до инициализации — фраза встанет в очередь. */
    fun speak(text: String) {
        if (!ready) {
            pending = text
            return
        }
        requestFocus()
        tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, UUID.randomUUID().toString())
    }

    private fun requestFocus() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val attrs = AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_ASSISTANCE_NAVIGATION_GUIDANCE)
                .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                .build()
            val request = AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN_TRANSIENT_MAY_DUCK)
                .setAudioAttributes(attrs)
                .setWillPauseWhenDucked(false)
                .build()
            focusRequest = request
            audioManager.requestAudioFocus(request)
        } else {
            @Suppress("DEPRECATION")
            audioManager.requestAudioFocus(
                null,
                AudioManager.STREAM_MUSIC,
                AudioManager.AUDIOFOCUS_GAIN_TRANSIENT_MAY_DUCK,
            )
        }
    }

    fun stop() {
        tts?.stop()
    }

    fun release() {
        tts?.shutdown()
        tts = null
        focusRequest?.let {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                audioManager.abandonAudioFocusRequest(it)
            }
        }
        focusRequest = null
    }
}
