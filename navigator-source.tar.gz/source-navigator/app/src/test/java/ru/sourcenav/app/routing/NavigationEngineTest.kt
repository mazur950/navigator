package ru.sourcenav.app.routing

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class NavigationEngineTest {

    private val route = RoutingApi.Route(
        points = listOf(
            RoutingApi.Point(56.0106, 92.8526),
            RoutingApi.Point(56.0110, 92.8530),
        ),
        maneuvers = listOf(
            RoutingApi.Maneuver("Начинайте движение по маршруту", 20.0),
            RoutingApi.Maneuver("Поверните направо на Мира", 40.0),
        ),
    )

    @Test
    fun `плохая точность GPS не порождает подсказок`() {
        val engine = NavigationEngine(route)
        val spoken = engine.onPosition(
            RoutingApi.Point(56.0106, 92.8526),
            NavigationEngine.Accuracy(meters = 50.0),
        )
        assertNull(spoken)
    }

    @Test
    fun `хорошая точность даёт подсказку на подходе`() {
        val engine = NavigationEngine(route)
        // Точка в 15 метрах от начальной — внутри зоны предупреждения,
        // но раньше зоны «сейчас».
        val spoken = engine.onPosition(
            RoutingApi.Point(56.0107, 92.8527),
            NavigationEngine.Accuracy(meters = 5.0),
        )
        assertEquals("Начинайте движение по маршруту. Через 20 метров", spoken)
    }

    @Test
    fun `расстояние между точками считается верно`() {
        val a = RoutingApi.Point(56.0106, 92.8526)
        val b = RoutingApi.Point(56.0110, 92.8530)
        val d = NavigationEngine.distanceMeters(a, b)
        // Порядок величины: несколько десятков метров. Точное значение
        // зависит от широты, важна не она, а отсутствие грубых ошибок.
        assertTrue("расстояние $d м вне разумного диапазона", d in 30.0..70.0)
    }
}
